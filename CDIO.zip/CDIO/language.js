const translations = {
    en: {
        title: "Smart Time Manager",
        description: "Organize, Track & Get Reminded of Your Tasks",
        createTask: "Create New Task",
        upcomingTasks: "Upcoming Tasks",
        logout: "Logout"
    },
    vi: {
        title: "Quản lý Thời gian Thông minh",
        description: "Tổ chức, Theo dõi & Nhận nhắc nhở về nhiệm vụ của bạn",
        createTask: "Tạo nhiệm vụ mới",
        upcomingTasks: "Nhiệm vụ sắp tới",
        logout: "Đăng xuất"
    },
    zh_CN: {  // Simplified Chinese (Mainland China)
        title: "智能时间管理",
        description: "组织、跟踪和提醒您的任务",
        createTask: "创建新任务",
        upcomingTasks: "即将到来的任务",
        logout: "登出"
    },
    zh_TW: {  // Traditional Chinese (Taiwan, Hong Kong)
        title: "智慧時間管理",
        description: "組織、追蹤和提醒您的任務",
        createTask: "創建新任務",
        upcomingTasks: "即將到來的任務",
        logout: "登出"
    },
    ko: {  // Korean
        title: "스마트 시간 관리",
        description: "작업을 정리하고 추적하며 알림을 받으세요",
        createTask: "새 작업 생성",
        upcomingTasks: "다가오는 작업",
        logout: "로그아웃"
    },
    ja: {  // Japanese
        title: "スマートタイムマネージャー",
        description: "タスクを整理、追跡し、リマインダーを受け取る",
        createTask: "新しいタスクを作成",
        upcomingTasks: "今後のタスク",
        logout: "ログアウト"
    }
};

function changeLanguage(lang) {
    document.querySelector("h1").textContent = translations[lang].title;
    document.querySelector("header p").textContent = translations[lang].description;
    document.querySelector(".section h2").textContent = translations[lang].createTask;
    document.getElementById("taskInput").setAttribute("placeholder", translations[lang].taskPlaceholder);
    document.querySelectorAll(".section h2")[1].textContent = translations[lang].upcomingTasks;
    document.querySelector("button[onclick='logout()']").textContent = translations[lang].logout;
}

// Event listener for language change
document.getElementById("languageSwitcher").addEventListener("change", function () {
    changeLanguage(this.value);
});

// Set default language on page load
window.onload = function () {
    const defaultLang = "en"; // Set default language
    document.getElementById("languageSwitcher").value = defaultLang;
    changeLanguage(defaultLang);
};
