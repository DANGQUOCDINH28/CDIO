// app.js
const taskList = document.getElementById('taskList');
const scheduleList = document.getElementById('scheduleList');
const taskInput = document.getElementById('taskInput');
const taskDateInput = document.getElementById('taskDate');

// Load tasks from localStorage when the page loads
window.onload = function() {
  loadTasks(false);
  loadSchedule();  // Load the schedule as well when the page loads
};

// Function to add a task
function addTask() {
  const task = taskInput.value.trim();
  const taskDate = taskDateInput.value;  // Get the selected date and time

  if (task && taskDate) {
    let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
    tasks.push({ task, date: taskDate, completed: false });
    localStorage.setItem('tasks', JSON.stringify(tasks));
    taskInput.value = '';
    taskDateInput.value = '';  // Clear the date picker after adding
    loadTasks(false);  // Refresh the task list
    loadSchedule();  // Refresh the schedule list after adding a task
  } else {
    alert("Please enter a task and select a date/time.");
  }
}

// Function to load tasks from localStorage and display them
function loadTasks(sortByDate) {
  let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
  
  if (sortByDate) {
    tasks = tasks.sort((a, b) => new Date(a.date) - new Date(b.date));  // Sort by date
  }

  taskList.innerHTML = '';
  tasks.forEach((item, index) => {
    const li = document.createElement('li');
    li.textContent = `${item.task} (Scheduled for: ${new Date(item.date).toLocaleString()})`;

    // Add a checkbox to mark tasks as completed
    const checkbox = document.createElement('input');
    checkbox.type = 'checkbox';
    checkbox.checked = item.completed;
    checkbox.onclick = function() {
      toggleTaskCompletion(index);
    };

    // Add an Edit button to update the task
    const editButton = document.createElement('button');
    editButton.textContent = 'Edit';
    editButton.onclick = function() {
      editTask(index);
    };

    // Add a Remove button to delete the task
    const removeButton = document.createElement('button');
    removeButton.textContent = 'Remove';
    removeButton.onclick = function() {
      removeTask(index);
    };

    li.prepend(checkbox);
    li.appendChild(editButton);
    li.appendChild(removeButton);
    taskList.appendChild(li);
  });
}

// Function to load the schedule of upcoming tasks
function loadSchedule() {
  let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
  
  // Filter tasks to show only future tasks
  const upcomingTasks = tasks.filter(task => new Date(task.date) > new Date());  // Only tasks scheduled for the future
  
  scheduleList.innerHTML = '';  // Clear the schedule list
  
  // If no upcoming tasks, display a message
  if (upcomingTasks.length === 0) {
    const noTasksMessage = document.createElement('li');
    noTasksMessage.textContent = "No upcoming tasks.";
    scheduleList.appendChild(noTasksMessage);
  }
  
  // Display the upcoming tasks
  upcomingTasks.forEach(item => {
    const li = document.createElement('li');
    li.textContent = `${item.task} (Scheduled for: ${new Date(item.date).toLocaleString()})`;
    scheduleList.appendChild(li);
  });
}

// Function to toggle task completion
function toggleTaskCompletion(index) {
  let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
  tasks[index].completed = !tasks[index].completed;
  localStorage.setItem('tasks', JSON.stringify(tasks));
  loadTasks(false);  // Refresh the task list
  loadSchedule();  // Refresh the schedule list
}

// Function to edit a task
function editTask(index) {
  let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
  const taskToEdit = tasks[index].task;
  const dateToEdit = tasks[index].date;

  // Set the input field to the task text and date/time
  taskInput.value = taskToEdit;
  taskDateInput.value = dateToEdit;

  // Update the task when the user submits a new value
  const updateButton = document.createElement('button');
  updateButton.textContent = 'Update Task';
  updateButton.onclick = function() {
    const updatedTask = taskInput.value.trim();
    const updatedDate = taskDateInput.value;

    if (updatedTask && updatedDate) {
      tasks[index].task = updatedTask;  // Update the task text
      tasks[index].date = updatedDate;  // Update the task date/time
      localStorage.setItem('tasks', JSON.stringify(tasks));
      loadTasks(false);  // Refresh the task list
      taskInput.value = '';  // Clear the input field
      taskDateInput.value = '';  // Clear the date picker
      updateButton.remove();  // Remove the update button
      loadSchedule();  // Refresh the schedule list after updating a task
    } else {
      alert("Please enter a task and select a date/time.");
    }
  };

  document.body.appendChild(updateButton);  // Add the update button to the page
}

// Function to remove a task
function removeTask(index) {
  let tasks = JSON.parse(localStorage.getItem('tasks')) || [];     
  tasks.splice(index, 1);  // Remove task from the array
  localStorage.setItem('tasks', JSON.stringify(tasks));
  loadTasks(false);  // Refresh the task list
  loadSchedule();  // Refresh the schedule list after removing a task
}

// Function to clear all tasks
function clearTasks() {
  localStorage.removeItem('tasks');
  loadTasks(false);  // Refresh the task list
  loadSchedule();  // Refresh the schedule list after clearing all tasks
}

// Function to remove completed tasks
function removeCompletedTasks() {
  let tasks = JSON.parse(localStorage.getItem('tasks')) || [];
  tasks = tasks.filter(task => !task.completed);  // Remove tasks that are marked as completed
  localStorage.setItem('tasks', JSON.stringify(tasks));
  loadTasks(false);  // Refresh the task list
  loadSchedule();  // Refresh the schedule list after removing completed tasks
}